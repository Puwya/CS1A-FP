#include "finalproj.h"

int menu()
{
    std::cout << std::endl;
    std::cout << "1) Mirror Horizontally " << std::endl;
    std::cout << "2) Mirror Vertically " << std::endl;
    std::cout << "3) Convert to Negative " << std::endl;
    std::cout << "4) Exit" << std::endl << std::endl;
    std::cout << std::endl;
    std::cout << "What would you like to do: ";

   return 0;
}


